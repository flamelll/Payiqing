package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import bean.info;
import dao.searchdao;


/**
 * Servlet implementation class searchservlet
 */
@WebServlet("/searchservlet")
public class searchservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public searchservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
				request.setCharacterEncoding("utf-8");
		        response.setContentType("text/html;charset=utf-8");
		       
		        request.setCharacterEncoding("UTF-8");
		        String date ="1=1";
				date = request.getParameter("date");
				String date1="1=1";
				date1 = request.getParameter("date1");
		        searchdao sd = new searchdao();
		        System.out.println(date);
		        System.out.println(date1);
		        List<info> list1 = sd.selectdate(date,date1);
		        List<info> list = sd.selectdate1(date,date1);
		        request.setAttribute("list1", list1);
		        request.setAttribute("list", list);
		        System.out.println("hhhhh");
		        request.getRequestDispatcher("ECharts.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
