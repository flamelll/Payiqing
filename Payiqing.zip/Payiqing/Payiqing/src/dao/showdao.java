package dao;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import bean.info;
import util.DBUtil;
public class showdao {
	public List<info>select(){
		int i=0;
		Connection conn = DBUtil.getConn(); //�������ݿ�
	    List<info> list = new ArrayList<info>();
	    try {
	        String sql="select * from info";
	        Statement pstmt = (Statement) conn.createStatement();
	        ResultSet rs = (ResultSet) pstmt.executeQuery(sql);
	        while(rs.next()) {
	        	info info=new info();
	        	info.setId(rs.getInt("Id"));
	        	info.setDate(rs.getString("Date"));
	        	info.setProvince(rs.getString("Province"));
	        	info.setCity(rs.getString("City"));
	        	info.setConfirmed_num(rs.getString("Confirmed_num"));
	        	info.setYisi_num(rs.getString("Yisi_num"));
	        	info.setCured_num(rs.getString("Cured_num"));
	        	info.setDead_num(rs.getString("Dead_num"));
	        	info.setCode(rs.getString("Code"));
	            list.add(info);
	            i++;
	            if(i>31) {
	            	break;
	            }
	        }
	        System.out.println("hhh1");
	        rs.close();
	        pstmt.close();
	        conn.close();

	    }catch(SQLException e) {
	        e.printStackTrace();
	    }
	    return list;
	    
	}
	public List<info>select1(){
		
		Connection conn = DBUtil.getConn(); //�������ݿ�
	    List<info> list1 = new ArrayList<info>();
	    try {
	        String sql="select * from info";
	        Statement pstmt = (Statement) conn.createStatement();
	        ResultSet rs = (ResultSet) pstmt.executeQuery(sql);
	        while(rs.next()) {
	        	info info=new info();
	        	info.setId(rs.getInt("Id"));
	        	info.setDate(rs.getString("Date"));
	        	info.setProvince(rs.getString("Province"));
	        	info.setCity(rs.getString("City"));
	        	info.setConfirmed_num(rs.getString("Confirmed_num"));
	        	info.setYisi_num(rs.getString("Yisi_num"));
	        	info.setCured_num(rs.getString("Cured_num"));
	        	info.setDead_num(rs.getString("Dead_num"));
	        	info.setCode(rs.getString("Code"));
	            list1.add(info);
	        }
	        System.out.println("hhh1");
	        rs.close();
	        pstmt.close();
	        conn.close();

	    }catch(SQLException e) {
	        e.printStackTrace();
	    }
	    return list1;
	    
	}

}
