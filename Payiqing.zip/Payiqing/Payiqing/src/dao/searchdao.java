package dao;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import bean.info;
import util.DBUtil;
public class searchdao {
	public List<info>selectdate(String date,String date1){
      System.out.println(date+"����date");
      System.out.println(date1+"����date1");
		Connection conn = DBUtil.getConn(); //�������ݿ�
	    List<info> list = new ArrayList<info>();
	    try {
	        String sql="select * from info where Date between '"+date+"' and '"+date1+"'";
	        Statement pstmt = (Statement) conn.createStatement();
	        ResultSet rs = (ResultSet) pstmt.executeQuery(sql);
	        while(rs.next()) {
	        	info info=new info();
	        	info.setId(rs.getInt("Id"));
	        	info.setDate(rs.getString("Date"));
	        	info.setProvince(rs.getString("Province"));
	        	info.setCity(rs.getString("City"));
	        	info.setConfirmed_num(rs.getString("Confirmed_num"));
	        	info.setYisi_num(rs.getString("Yisi_num"));
	        	info.setCured_num(rs.getString("Cured_num"));
	        	info.setDead_num(rs.getString("Dead_num"));
	        	info.setCode(rs.getString("Code"));
	            list.add(info);
	        }
	        System.out.println("hhh1");
	        rs.close();
	        pstmt.close();
	        conn.close();

	    }catch(SQLException e) {
	        e.printStackTrace();
	    } 
	    return list;
	    
	}
	public List<info>selectdate1(String date,String date1){
		int i=0;
		Connection conn = DBUtil.getConn(); //�������ݿ�
	    List<info> list = new ArrayList<info>();
	    try {
	        String sql="select * from info where Date between '"+date+"' and '"+date1+"'";
	        Statement pstmt = (Statement) conn.createStatement();
	        ResultSet rs = (ResultSet) pstmt.executeQuery(sql);
	        while(rs.next()) {
	        	info info=new info();
	        	info.setId(rs.getInt("Id"));
	        	info.setDate(rs.getString("Date"));
	        	info.setProvince(rs.getString("Province"));
	        	info.setCity(rs.getString("City"));
	        	info.setConfirmed_num(rs.getString("Confirmed_num"));
	        	info.setYisi_num(rs.getString("Yisi_num"));
	        	info.setCured_num(rs.getString("Cured_num"));
	        	info.setDead_num(rs.getString("Dead_num"));
	        	info.setCode(rs.getString("Code"));
	            list.add(info);
	            i++;
	            if(i>31) {
	            	break;
	            }
	        }
	        System.out.println("hhh1");
	        rs.close();
	        pstmt.close();
	        conn.close();

	    }catch(SQLException e) {
	        e.printStackTrace();
	    }
	    return list;}}